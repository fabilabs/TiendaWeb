import "./cliente.css";
import Menu from "../Menu/Menu";
import { useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";

function Cliente() {
  const [infoClientes, modificarinfoClientes] = useState([]); //useState sirve para renderizar al notar un cambio
  const navigate = useNavigate();
  const MySwal = withReactContent(Swal);

  useEffect(() => {
    cargarClientes();
  }, []);

  function FormCliente() {
    navigate("/FormCliente");
  }

  const cargarClientes = async () => {
    const response = await fetch("http://localhost:8080/listarCliente");
    const data = await response.json();
    modificarinfoClientes(data);
  };


  const eliminarCliente = async (cedula) => {
    MySwal.fire({
      title: "Seguro que quieres eliminar el Cliente?",
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: "Si",
      denyButtonText: `No`,
    }).then ( async(result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        const response = await fetch(
          "http://localhost:8080/eliminarCliente/" + cedula,
          {
            method: "DELETE",
            mode: "cors",
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "http://localhost:3000",
            },
          }
        );
        const respuesta = await response.json();
        if (respuesta) {
          const foundCliente = infoClientes.filter(
            //(element) => element.cedula_Cliente != cedula // *_*
            (element) => element.cedula_Cliente != cedula
          );
          modificarinfoClientes(foundCliente);
        }

        MySwal.fire("Eliminado!", "", "success");
      } else if (result.isDenied) {
        
      }
    });
  };

  const redireccionForCliente = (cedula) => {
    navigate("/FormCliente/"+cedula);
  }

  const generarTabla = () => {
    return infoClientes.map((element) => (
      <tr key={element.cedula_Cliente}>
        <td> {element.cedula_Cliente} </td>
        <td> {element.nombre_Cliente} </td>
        <td> {element.correo_Cliente} </td>
        <td> {element.direccion_Cliente} </td>
        <td> {element.telefono_Cliente} </td>
        <td>
          <button 
          className="btn btn-outline-primary btn-sm marginButtonCliente bi bi-pencil-fill"
          onClick={(e) => redireccionForCliente(element.cedula_Cliente) }
          ></button>
          <button
            className="btn btn-danger btn-sm marginButtonCliente bi bi-trash "
            onClick={(e) => eliminarCliente(element.cedula_Cliente)}
          ></button>
        </td>
      </tr>
    ));
  };


  return (
    <div className="flex">
      <Menu></Menu>
      <div className="anchoMenu">
        <div className="ClienteTabla">
          <div class="ClienteTitulo">
            <h1>Lista de Clientes</h1>
          </div>

          <table class="ClienteTablaAncho table table-striped mx-auto">
            <thead>
              <tr>
                <th>CEDULA</th>
                <th>NOMBRE</th>
                <th>CORREO</th>
                <th>DIRECCION</th>
                <th>TELEFONO</th>
                <th>ACCIONES</th>
              </tr>
            </thead>
            <tbody>{generarTabla()}</tbody>
          </table>
          <div class=" ClienteTablaAncho mx-auto">
            <a>
              < button  className="btn btn-primary" 
                onClick={FormCliente}>
                Nuevo
              </button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Cliente;
