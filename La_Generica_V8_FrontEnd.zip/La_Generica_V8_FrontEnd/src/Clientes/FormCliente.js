import "./cliente.css";
import Menu from "../Menu/Menu";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";

function FormCliente() {
  //const navigate = useNavigate();
  const MySwal = withReactContent(Swal);
  const navigate2 = useNavigate();

  let params = useParams(); // captura parameetros de la url { cedula }

  const InicializarForm = async () => {
    // validar si hay algo en el parametro cedula
    if (params.cedula) {
      // hacer un get por cedula para traer los datos
      // despues de tener los datos asociales a los input los datos correspondientes
      const response = await fetch(
        "http://localhost:8080/Cliente/" + params.cedula
      );
      const data = await response.json();
      console.log(data);
      document.getElementById("cedula_Clientes").value = data.cedula_Cliente;
      document.getElementById("nombre_Clientes").value = data.nombre_Cliente;
      document.getElementById("correo_Clientes").value = data.correo_Cliente;
      document.getElementById("direccion_Clientes").value = data.direccion_Cliente;
      document.getElementById("telefono_Clientes").value = data.telefono_Cliente;
      
    }
  };
  useEffect(() => {
    //sirve para ejecutar esa funcion apenas carga o cuando cambia una variable dentro de la funcion
    InicializarForm();
  }, []);

  const crearNuevoCliente = async (e) => {
    e.preventDefault();

    const cedulaCliente = document.getElementById("cedula_Clientes").value;
    const direccionCliente = document.getElementById("direccion_Clientes").value;
    const nombreCliente = document.getElementById("nombre_Clientes").value;
    const telefonoCliente = document.getElementById("telefono_Clientes").value;
    const correoCliente = document.getElementById("correo_Clientes").value;

    if (
      cedulaCliente &&
      nombreCliente &&
      direccionCliente &&
      telefonoCliente &&
      correoCliente
    ) {
      const clienteCompleto = {
        cedula_Cliente: cedulaCliente,
        correo_Cliente: correoCliente,
        direccion_Cliente: direccionCliente,
        nombre_Cliente: nombreCliente,
        telefono_Cliente: telefonoCliente
        // cliente, clave_Clienteson las variables del modelo en eclipse mismo nombre
      };
      const response = await fetch("http://localhost:8080/saveCliente", {
        //aqui envia la inf
        method: "POST", // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, *cors, same-origin
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(clienteCompleto), // body data type must match "Content-Type" header
      });
      const respuesta = await response.json();

      if (respuesta) {
        MySwal.fire(
          "cliente agregado",
          "El cliente se agrego exitosamente",
          "success"
        );

        navigate2("/cliente");
      } else {
        MySwal.fire(
          "Datos Incompletos",
          "Por favor complete todos los campos",
          "error"
        );
      }
    }
  };



  return (
    <div className="flex">
      <Menu></Menu>
      <div className="anchoMenu">
        <form>
          <div className="ClienteTitulo">
            <h1>Formulario - Ingresar Cliente</h1>
          </div>
          <div className="Contenido_Clientes">
            <div className="Contenido_Clientes_div">
              <div className="Contenido_Clientes_cuadros">
                <label for="Cédula"> Cédula </label>
                <input
                  id="cedula_Clientes"
                  type="text"
                  name="cedula_Clientes"
                  placeholder="Digite la cédula"
                />
                <br />
              </div>

              <div className="Contenido_Clientes_cuadros">
                <label for="Telefono"> Telefono </label>
                <input
                  id="telefono_Clientes"
                  type="text"
                  name="telefono_Clientes"
                  placeholder="Digite el telefono"
                />
                <br />
              </div>
            </div>
            <div className="Contenido_Clientes_div">
              <div className="Contenido_Clientes_cuadros">
                <label for="Nombre_Completo"> Nombre Completo </label>
                <input
                  id="nombre_Clientes"
                  type="text"
                  name="nombre_Clientes"
                  placeholder="Digite el nombre"
                />
                <br />
              </div>

              <div className="Contenido_Clientes_cuadros">
                <label for="Correo_Electronico"> Correo Electronico </label>
                <input
                  id="correo_Clientes"
                  type="text"
                  name="correo_Clientes"
                  placeholder="Digite el correo"
                />
                <br />
              </div>
            </div>

            <div className="Contenido_Clientes_div">
              <div className="Contenido_Clientes_cuadros">
                <label for="Dirección"> Dirección </label>
                <input
                  id="direccion_Clientes"
                  type="text"
                  name="direccion_Clientes"
                  placeholder="Digite la direccion"
                />
                <br />
              </div>
            </div>
          </div>
          <div class="botones_Clientes">
            <div className="botones_Clientes_conte">
              <button
                type="submit"
                name="consultar_Clientes"
                class="btn btn-primary btn-lg active"
                onClick={crearNuevoCliente}
              >
                Guardar
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
export default FormCliente;
