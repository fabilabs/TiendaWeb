import "./Consolidacion.css";
import Menu from "../Menu/Menu";
import React, { useMemo,useState,Component,useEffect} from "react";
//import Select from 'react-select';
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import { createSearchParams } from "react-router-dom";
//import { useNavigate } from "react-router-dom";

//var ventasCiudad  = [{value: 0 , label: "Bogota" },{value: 0 , label: "Cali" },{value: 0 , label: "Medellin" }];
var ventasBogota = 0; 
var ventasCali = 0; 
var ventasMedellin = 0; 
var ventas_totales = 0;

function Consolidacion() 
{
    const [infoVentas, modificarInfoVentas] = useState([]); //useState sirve para renderizar al notar un cambio
   // const navigate = useNavigate();
    //const MySwal = withReactContent(Swal);

    useEffect(() => {
        calcularVentasCidudades();
      }, []);
    

    const calcularVentasCidudades= async (e) =>{
        const response = await fetch("http://localhost:8080//listarFacturas");
        const data = await response.json();
        modificarInfoVentas(data);
        for(const x in data){
           if("Bogota" == data[parseInt(x)].ciudad) {
                ventasBogota = parseFloat(data[parseInt(x)].valor_Total) + ventasBogota;
            }
            if("Medellin" == data[parseInt(x)].ciudad) {
                ventasMedellin = parseFloat(data[parseInt(x)].valor_Total) + ventasMedellin;
            }
            if("Cali" == data[parseInt(x)].ciudad) {
                ventasCali = parseFloat(data[parseInt(x)].valor_Total) + ventasCali;
            }
           ventas_totales = ventas_totales + parseFloat(data[parseInt(x)].valor_Total);
          }
          document.getElementById("ventas_Totales_text").value = ventas_totales ;
          document.getElementById("inputValorVentasBogota").value = ventasBogota ;
          document.getElementById("inputValorVentasMedellin").value = ventasMedellin ;
          document.getElementById("inputValorVentasCali").value = ventasCali ;

          ventas_totales = 0;
          ventasBogota = 0;
          ventasMedellin = 0;
          ventasCali = 0;
    }

    const mostrarCiudad = async (e) =>{
        /*
        document.getElementById("inputBogota").value = "Bogota"; 
        document.getElementById("inputValorVentasBogota").value = "Plata en Bogota"; 
        document.getElementById("inputCali").value = "Cali"; 
        document.getElementById("inputValorVentasCali").value = "Plata en Cali"; 
        document.getElementById("inputMedellin").value = "Medellin"; 
        document.getElementById("inputValorVentasMedellin").value = "Plata en Medellin"; 
        document.getElementById("ventas_Totales_text").value = "cero pollitos"; 
        
        calcularVentasCidudades();
        */
      }

return (
    <div className="flex">
      <Menu></Menu>
      <div className="anchoMenu">
        <form method="POST">
         <div class="VentasTitulo">
            <h1>Total ventas por ciudad</h1>
          </div>
            <div className="Contenido_Ventas_Factura">
            <table className="tabla_Factura ">
            <tr>
                <th className="bordes_Tabla color_Gris">Ciudad</th>
                <th className="bordes_Tabla color_Gris">Valor Total Ventas</th>
            </tr>
            <tr>
                <td className="bordes_Tabla">
                <input
                    id="inputBogota"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                /> Bogotá
                </td>

                <td className="bordes_Tabla2">
                <input
                    id="inputValorVentasBogota"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                />
                </td>
            </tr>

            <tr>
                <td className="bordes_Tabla">
                <input
                    id="inputMedellin"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                /> Medellín
                </td>

                <td className="bordes_Tabla2">
                <input
                    id="inputValorVentasMedellin"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                />
                </td>
            </tr>

            <tr>
            <td className="bordes_Tabla">
                <input
                    id="inputCali"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                /> Cali
                </td>

                <td className="bordes_Tabla2">
                <input
                    id="inputValorVentasCali"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                />
                </td>

                <td className="alignCenter">
                </td>
            </tr>
            <tr>
                <th className="alignCenter"> </th>
                <th className="alignCenter"> </th>
            </tr>
            <tr>
                <th className="bordes_Tabla color_Gris">Total Ventas Tienda </th>
                <td className="bordes_Tabla2">
                <input
                    id="ventas_Totales_text"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                />
                </td>
            </tr>
            </table>
            </div>
        </form>
      </div>
    </div>

  );
}

export default Consolidacion;