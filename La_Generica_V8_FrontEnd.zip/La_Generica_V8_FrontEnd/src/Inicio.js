import Menu from './Menu/Menu'

function Inicio() {
  const estilos = {
    padre: {
      height: "90vh",
    },

    card: {
      width: "30%",
    },

	flex:{
		display: "flex",
	},

	ancho:{
		width: "86vw",

	}
  };

  

  return (
    <div style={estilos.flex}>
      <Menu></Menu>
      <div style={estilos.ancho}>
        <div
          className="row row-cols-1 row-cols-md-3 g-4 mx-5 my-3 "
          style={estilos.padre}
        >
          <div className="col " style={estilos.card}>
            <div className="card h-100">
              <img
                //src="https://misionticueb.myopenlms.net/pluginfile.php/1/tool_themeassets/assets/0/logo-mision-ubosque.png"
                src="mintic_12.png"
                className="card-img-top"
                alt="..."
              />
              <div className="card-body">
                <h5 className="card-title">
                  {" "}
                  <strong>4A DESARROLLO DE APLICACIONES WEB</strong>
                </h5>
                <p className="card-text">
                  Desarrollo web de una tienda genérica.
                </p>
              </div>
              <div className="card-footer bg-transparent border-white">
                <a
                  href="https://www.misiontic2022.gov.co/portal/"
                  target="blank"
                  className="btn btn-primary"
                >
                  MisionTic2022
                </a>
              </div>
            </div>
          </div>

          <div className="col" style={estilos.card}>
            <div className="card h-100">
              <img
                //src="https://blog.trello.com/hubfs/Imported%20images/Global%20Footer%20CTA%20Image.png"
                src="Tecnologias12.png"
                className="card-img-top"
                alt="..."
              />
              <div className="card-body">
                <h5 className="card-title">
                  <strong>Desarrollo web de una tienda genérica</strong>
                </h5>
                <p className="card-text">
                  React + Mysql + SpringBoot fueron las tecnologías usadas.
                </p>
              </div>
              <div className="card-footer bg-transparent border-white">
                <a
                  href="/Ventas"
                  target="blank"
                  className="btn btn-primary"
                >
                  Ir a la tienda
                </a>
              </div>
            </div>
          </div>

          <div className="col" style={estilos.card}>
            <div className="card h-100">
              <img
                //src="https://github.githubassets.com/images/modules/site/icons/footer/github-logo.svg"
                src="Git12.png"
                className="card-img-top"
                alt="..."
              />
              <div className="card-body">
                <h5 className="card-title">
                  <strong>Repositorio</strong>
                </h5>
                <p className="card-text">
                  Repositorio en Github.com de este desarrollo
                </p>
              </div>
              <div className="card-footer bg-transparent border-white">
                <a href="https://github.com/" target="blank" className="btn btn-primary">
                  Ir al Repositorio
                </a>
              </div>
            </div>
          </div>

          <div className="col" style={estilos.card}>
            <div className="card h-100">
              <img
                //src="https://misionticueb.myopenlms.net/pluginfile.php/91348/theme_snap/coverimage/1630177066/course-image.jpg"
                src="Linkedin21.png"
                class="card-img-top"
                alt="..."
              />
              <div className="card-body">
                <h5 className="card-title">
                  <strong>Fabían Fagua</strong>
                </h5>
                <p className="card-text">
                  Grupo 13{" "}
                  <a
                    href="https://interacpedia.com/user/fabian-fagua"
                    target="blank"
                  >
                    Interacpedia                  
                  </a>
                </p>
                <div className="card-footer bg-transparent border-white">
                <a href="https://linkedin.com/in/fabian-fagua" target="blank" className="btn btn-primary">
                  Ir al Perfil 
                </a>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Inicio;
