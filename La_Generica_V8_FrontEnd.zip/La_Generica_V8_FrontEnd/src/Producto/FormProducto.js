import "./producto.css";
import Menu from "../Menu/Menu";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";

function FormProducto() {


   //const navigate = useNavigate();
   const MySwal = withReactContent(Swal);
   const navigate = useNavigate();
 
   let params = useParams(); // captura parameetros de la url { cedula }
 
   const InicializarForm = async () => {
     // validar si hay algo en el parametro codigo
     if (params.codigo) {
       // hacer un get por codigo para traer los datos
       // despues de tener los datos asociales a los input los datos correspondientes
       const response = await fetch(
         "http://localhost:8080/Producto/" + params.codigo
       );
       const data = await response.json();
       console.log(data);
       document.getElementById("codigo_Producto").value = data.codigo_Producto;
       document.getElementById("iva_Producto").value = data.iva_Producto;
       document.getElementById("nit_Proveedor").value = data.nit_Proveedor;
       document.getElementById("nombre_Producto").value = data.nombre_Producto;
       document.getElementById("costo").value = data.precio_Compra;
       document.getElementById("precio_Venta").value = data.precio_Venta_Producto;
     }
   };
   useEffect(() => {
     //sirve para ejecutar esa funcion apenas carga o cuando cambia una variable dentro de la funcion
     InicializarForm();
   }, []);
  
  
   const crearNuevoProducto = async (e) => {
    e.preventDefault();

    const codigoProducto = document.getElementById("codigo_Producto").value;
    const ivaProducto = document.getElementById("iva_Producto").value;
    const nitProducto = document.getElementById("nit_Proveedor").value;
    const nombreProducto = document.getElementById("nombre_Producto").value;
    const precioProducto = document.getElementById("costo").value;
    const precioVentaProducto = document.getElementById("precio_Venta").value;
    if (
      codigoProducto &&
      ivaProducto &&
      nitProducto &&
      nombreProducto &&
      precioProducto &&
      precioVentaProducto
    ) {
      const ProductoCompleto = {
        codigo_Producto: codigoProducto,
        nombre_Producto: nombreProducto,
        nit_Proveedor: nitProducto,
        precio_Compra: precioProducto,
        iva_Producto: ivaProducto,
        precio_Venta_Producto: precioVentaProducto,
        //  son las variables del modelo en eclipse mismo nombre
      };
      const response = await fetch("http://localhost:8080/saveProducto", {
        //aqui envia la inf
        method: "POST", // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, *cors, same-origin
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(ProductoCompleto), // body data type must match "Content-Type" header
      });
      const respuesta = await response.json();

      if (respuesta) {
        MySwal.fire(
          "Producto agregado",
          "El Producto se agrego exitosamente",
          "success"
        );

        navigate("/Producto");
      } else {
        MySwal.fire(
          "Datos Incompletos",
          "Por favor complete todos los campos",
          "error"
        );
      }
    }
  };


  return (
    <>
      <div className="flex">
        <Menu></Menu>
        <div className="anchoMenu">
          <form>
            <div className="ProductoTitulo">
              <h1>Formulario - Ingresar Productos</h1>
            </div>
            <div className="Contenido_Productos">
              <div className="Contenido_Productos_div">
                <div className="Contenido_Productos_cuadros">
                  <label for="Codigo"> Codigo </label>
                  <input
                    id="codigo_Producto"
                    type="text"
                    name="codigo_Producto"
                    placeholder="Digite el codigo"
                    />
                  <br />
                </div>

                <div className="Contenido_Productos_cuadros">
                  <label for="Nombre"> Producto </label>
                  <input
                    id="nombre_Producto"
                    type="text"
                    name="nombre_Producto"
                    placeholder="Digite nombre del producto"
                  />
                  <br />
                </div>
              </div>
              <div className="Contenido_Productos_div">
                <div className="Contenido_Productos_cuadros">
                  <label for="Nit_Proveedor"> Nit Proveedor </label>
                  <input
                    id="nit_Proveedor"
                    type="text"
                    name="nit_Proveedor"
                    placeholder="Digite NIT del proveedor"
                  />
                  <br />
                </div>

                <div className="Contenido_Productos_cuadros">
                  <label for="Costo"> Costo </label>
                  <input
                    id="costo"
                    type="text"
                    name="costo"
                    placeholder="Digite el costo"
                  />
                  <br />
                </div>
              </div>

              <div className="Contenido_Productos_div">
                <div className="Contenido_Productos_cuadros">
                  <label for="Iva"> IVA </label>
                  <input
                    id="iva_Producto"
                    type="text"
                    name="iva_Producto"
                    placeholder="Digite valor del IVA"
                  />
                  <br />
                </div>
                <div className="Contenido_Productos_cuadros">
                  <label for="Precio_Venta"> Precio Venta </label>
                  <input
                    id="precio_Venta"
                    type="text"
                    name="precio_Venta"
                    placeholder="Digite valor de venta"
                  />
                  <br />
                </div>
              </div>
            </div>
            <div className="botones_Productos">
              <div className="botones_Productos_conte">
                <button
                  type="submit"
                  name="consultar_Productos"
                  class="btn btn-primary btn-lg active"
                  onClick={crearNuevoProducto}
                >
                  Guardar
                </button>
              </div>
            </div>
          </form>

          <div className="row espacioBotonCarga" align="center">
            <h2>Cargar masiva por archivo .csv</h2>
            <form action="" method="post" enctype="">
              <input
                type="file"
                name="file"
                accept=".csv"
                class="btn btn-secondary"
              />
              <input
                type="submit"
                name="btn_archivo"
                value="Cargar archivo csv"
                class="btn btn-primary"
              />
            </form>
          </div>
        </div>
      </div>
    </>
  );
}

export default FormProducto;
