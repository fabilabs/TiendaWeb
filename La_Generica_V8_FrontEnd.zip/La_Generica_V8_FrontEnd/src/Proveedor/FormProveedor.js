import "./proveedor.css";
import Menu from "../Menu/Menu";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";

function FormProveedor() {
  //const navigate = useNavigate();
  const MySwal = withReactContent(Swal);
  const navigate = useNavigate();

  let params = useParams(); // captura parameetros de la url { nit }

  const InicializarForm = async () => {
    // validar si hay algo en el parametro nit
    if (params.nit){
      // hacer un get por nit para traer los datos
      // despues de tener los datos asociales a los input los datos correspondientes
      const response = await fetch(
        "http://localhost:8080/Proveedor/"+params.nit
      );
      const data = await response.json();
      console.log(data);
      document.getElementById("nit_Proveedores").value = data.nit_Proveedor;
      document.getElementById("nombre_Proveedores").value = data.nombre_Proveedor;
      document.getElementById("direccion_Proveedores").value = data.direccion_Proveedor;
      document.getElementById("ciudad_Proveedores").value = data.ciudad_Proveedor;
      document.getElementById("telefono_Proveedores").value = data.telefono_Proveedor;
    }
  };
  useEffect(() => {
    //sirve para ejecutar esa funcion apenas carga o cuando cambia una variable dentro de la funcion
    InicializarForm();
  }, []);

  const crearNuevoProveedor = async (e) => {
    e.preventDefault();

    const nitProveedor = document.getElementById("nit_Proveedores").value;
    const nombreProveedor = document.getElementById("nombre_Proveedores").value;
    const direccionProveedor = document.getElementById("direccion_Proveedores").value;
    const ciudadProveedor = document.getElementById("ciudad_Proveedores").value;
    const telefonoProveedor = document.getElementById("telefono_Proveedores").value;

    if (
      nitProveedor &&
      nombreProveedor &&
      direccionProveedor &&
      ciudadProveedor &&
      telefonoProveedor
    ) {
      const ProveedorCompleto = {
        nit_Proveedor: nitProveedor,
        nombre_Proveedor: nombreProveedor,
        direccion_Proveedor: direccionProveedor,
        ciudad_Proveedor: ciudadProveedor,
        telefono_Proveedor: telefonoProveedor,
        // nit_proveedor, nombre_Proveedor son las variables del modelo en eclipse mismo nombre
      };
      const response = await fetch("http://localhost:8080/saveProveedor", {
        //aqui envia la inf
        method: "POST", // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, *cors, same-origin
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(ProveedorCompleto), // body data type must match "Content-Type" header
      });
      const respuesta = await response.json();

      if (respuesta) {
        MySwal.fire(
          "Proveedor agregado",
          "El Proveedor se agrego exitosamente",
          "success"
        );

        navigate("/Proveedor");
      } else {
        MySwal.fire(
          "Datos Incompletos",
          "Por favor complete todos los campos",
          "error"
        );
      }
    }
  };

  return (
    <div className="flex">
      <Menu></Menu>
      <div className="anchoMenu">
        <form>
          <div className="ProveedorTitulo">
            <h1>Formulario - Ingresar Proveedor</h1>
          </div>
          <div className="Contenido_Proveedores">
            <div className="Contenido_Proveedores_div">
              <div className="Contenido_Proveedores_cuadros">
                <label for="nit"> NIT </label>
                <input
                  id="nit_Proveedores"
                  type="text"
                  name="nit_Proveedores"
                  placeholder="Digite el NIT"
                />
                <br />
              </div>

              <div className="Contenido_Proveedores_cuadros">
                <label for="Telefono"> Telefono </label>
                <input
                  id="telefono_Proveedores"
                  type="text"
                  name="telefono_Proveedores"
                  placeholder="Digite el telefono"
                />
                <br />
              </div>
            </div>
            <div className="Contenido_Proveedores_div">
              <div className="Contenido_Proveedores_cuadros">
                <label for="Nombre"> Nombre Proveedor </label>
                <input
                  id="nombre_Proveedores"
                  type="text"
                  name="nombre_Proveedores"
                  placeholder="Digite el nombre"
                />
                <br />
              </div>

              <div className="Contenido_Proveedores_cuadros">
                <label for="Ciudad"> Ciudad </label>
                <input
                  id="ciudad_Proveedores"
                  type="text"
                  name="ciudad_Proveedores"
                  placeholder="Digite la ciudad"
                />
                <br />
              </div>
            </div>

            <div className="Contenido_Proveedores_div">
              <div className="Contenido_Proveedores_cuadros">
                <label for="Dirección"> Dirección </label>
                <input
                  id="direccion_Proveedores"
                  type="text"
                  name="direccion_Proveedores"
                  placeholder="Digite la direccion"
                />
                <br />
              </div>
            </div>
          </div>
          <div className="botones_Proveedores">
            <div className="botones_Proveedores_conte">
              <button
                type="submit"
                id="consultar_Proveedores"
                name="consultar_Proveedores"
                class="btn btn-primary btn-lg active"
                onClick={crearNuevoProveedor}
              >
                Guardar
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
export default FormProveedor;
