import "./proveedor.css";
import Menu from "../Menu/Menu";
import { useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import FormProveedor from "./FormProveedor";

function Proveedor() {
  const [infoProveedores, modificarInfoProveedores] = useState([]); //useState sirve para renderizar al notar un cambio
  const navigate = useNavigate();
  const MySwal = withReactContent(Swal);

  useEffect(() => {
    cargarProveedores();
  }, []);

  function FormProveedores() {
    navigate("/FormProveedor");
  }

  const cargarProveedores = async () => {
    const response = await fetch("http://localhost:8080/listarProveedor");
    const data = await response.json();
    modificarInfoProveedores(data);
  };

  const eliminarProveedor = async (nit) => {
    MySwal.fire({
      title: "Seguro que quieres eliminar el Proveedor?",
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: "Si",
      denyButtonText: `No`,
    }).then ( async(result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        const response = await fetch(
          "http://localhost:8080/eliminarProveedor/" + nit,
          {
            method: "DELETE",
            mode: "cors",
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "http://localhost:3000",
            },
          }
        );
        const respuesta = await response.json();
        if (respuesta) {
          const foundProveedor = infoProveedores.filter(
            //(element) => element.cedula_Proveedor != cedula // *_*
            (element) => element.nit_Proveedor != nit
          );
          modificarInfoProveedores(foundProveedor);
        }

        MySwal.fire("Eliminado!", "", "success");
      } else if (result.isDenied) {
        
      }
    });
  };

  const redireccionForProveedor = (nit) => {
    navigate("/formProveedor/"+nit);
  }
  const generarTabla = () => {
    return infoProveedores.map((element) => (
      <tr key={element.nit_Proveedor}>
        <td> {element.nit_Proveedor} </td>
        <td> {element.nombre_Proveedor} </td>
        <td> {element.direccion_Proveedor} </td>
        <td> {element.ciudad_Proveedor} </td>
        <td> {element.telefono_Proveedor} </td>
        <td>
          <button 
          className="btn btn-outline-primary btn-sm marginButtonProveedor bi bi-pencil-fill"
          onClick={(e) => redireccionForProveedor (element.nit_Proveedor) }
          ></button>
          <button
            className="btn btn-danger btn-sm marginButtonProveedor bi bi-trash "
            onClick={(e) => eliminarProveedor(element.nit_Proveedor)}
          ></button>
        </td>
      </tr>
    ));
  };

  return (
    <>
      <div className="flex">
        <Menu></Menu>
        <div className="anchoMenu">
          <div className="ProveedorTabla">
            <div class="ProveedorTitulo">
              <h1>Lista de Proveedores</h1>
            </div>

            <table class="ProveedorTablaAncho table table-striped mx-auto">
              <thead>
                <tr>
                  <th>NIT</th>
                  <th>NOMBRE</th>
                  <th>DIRECCION</th>
                  <th>CIUDAD</th>
                  <th>TELEFONO</th>
                  <th>ACCIONES</th>
                </tr>
              </thead>
              <tbody> {generarTabla()}</tbody>
            </table>
            <div class="ProveedorTablaAncho mx-auto">
              <a>
                <button className="btn btn-primary" onClick={FormProveedores}>
                Nuevo
                </button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Proveedor;


/*
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td>
                    <a className="btn btn-outline-primary btn-sm marginButtonUsuario bi bi-pencil-fill"></a>
                    <a className="btn btn-danger btn-sm marginButtonUsuario bi bi-trash ">
                      {" "}
                    </a>
                  </td>
                </tr>
              </tbody>
*/