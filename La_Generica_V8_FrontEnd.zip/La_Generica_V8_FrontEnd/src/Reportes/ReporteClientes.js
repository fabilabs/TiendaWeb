import "./reportes.css";
import Menu from "../Menu/Menu";
import { useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";

function ReporteClientes() {

  const [infoClientes, modificarInfoClientes] = useState([]); //useState sirve para renderizar al notar un cambio
  const navigate = useNavigate();
  const MySwal = withReactContent(Swal);


  useEffect(() => {
    cargarClientes();
  }, []);

  const cargarClientes = async () => {
    const response = await fetch("http://localhost:8080/listarCliente");
    const data = await response.json();
    modificarInfoClientes(data);
  };

  const generarTabla = () => {
    return infoClientes.map((element) => (
      <tr key={element.cedula_Cliente}>
        <td> {element.cedula_Cliente} </td>
        <td> {element.nombre_Cliente} </td>
        <td> {element.correo_Cliente} </td>
        <td> {element.direccion_Cliente} </td>
        <td> {element.telefono_Cliente} </td>
      </tr>
    ));
  };




  return (
    <div className="flex">
      <Menu></Menu>
      <div className="anchoMenu">
        <div>
          <div class="ReportesTitulo">
            <h1>Reporte de Clientes</h1>
          </div>

          <table class=" VentasClientesTablaAncho table table-striped mx-auto">
            <thead>
              <tr>
                <th>CEDULA CLIENTE</th>
                <th>NOMBRE CLIENTE</th>
                <th>CORREO</th>
                <th>DIRECCIÓN</th>
                <th>TELEFONO</th>
              </tr>
            </thead>
            <tbody>{generarTabla()}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default ReporteClientes;
