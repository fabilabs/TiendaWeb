import "./reportes.css";
import Menu from "../Menu/Menu";
import { useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";


function ReporteUsuarios() {

  const [infoUsuarios, modificarInfoUsuarios] = useState([]); //useState sirve para renderizar al notar un cambio
  const navigate = useNavigate();
  const MySwal = withReactContent(Swal);


  useEffect(() => {
    cargarUsuarios();
  }, []);

  const cargarUsuarios = async () => {
    const response = await fetch("http://localhost:8080/listarUsuario");
    const data = await response.json();
    modificarInfoUsuarios(data);
  };

  const generarTabla = () => {
    return infoUsuarios.map((element) => (
      <tr key={element.cedula_Usuario}>
        <td> {element.cedula_Usuario} </td>
        <td> {element.nombre_Usuario} </td>
        <td> {element.correo_Usuario} </td>
        <td> {element.usuario} </td>
        <td> {element.clave_Usuario} </td>
      </tr>
    ));
  };



  return (
    <div className="flex">
      <Menu></Menu>
      <div className="anchoMenu">
        <div>
          <div class="ReportesTitulo">
            <h1>Reporte de Usuarios</h1>
          </div>

          <table class=" VentasClientesTablaAncho table table-striped mx-auto">
            <thead>
              <tr>
                <th>CEDULA USUARIO</th>
                <th>NOMBRE USUARIO</th>
                <th>CORREO</th>
                <th>USUARIO</th>
                <th>PASSWORD</th>
              </tr>
            </thead>
            <tbody>{generarTabla()}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default ReporteUsuarios;
