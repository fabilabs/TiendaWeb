import "./reportes.css";
import Menu from "../Menu/Menu";
import { useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";




function VentasPorCliente() {

  const [infoVentas, modificarInfoVentas] = useState([]); //useState sirve para renderizar al notar un cambio
  const navigate = useNavigate();
  const MySwal = withReactContent(Swal);


  useEffect(() => {
    cargarVentas();
  }, []);

  const cargarVentas = async () => {
    const response = await fetch("http://localhost:8080//listarFacturas");
    const data = await response.json();
    modificarInfoVentas(data);
  };

  const generarTabla = () => {
    return infoVentas.map((element) => (
      <tr key={element.codigo_Vta}>
        <td> {element.cedula_Cli_Vta} </td>
        <td> {element.nombre_Cli_Vta} </td>
        <td> {element.valor_Vta} </td>
        <td> {element.valor_IVA} </td>
        <td> {element.valor_Total} </td>
      </tr>
    ));
  };


  return (
    <div className="flex">
      <Menu></Menu>
      <div className="anchoMenu">
        <div>
          <div class="ReportesTitulo">
            <h1>Ventas por Cliente</h1>
          </div>

          <table class=" VentasClientesTablaAncho table table-striped mx-auto">
            <thead>
              <tr>
                <th>CEDULA CLIENTE</th>
                <th>NOMBRE CLIENTE</th>
                <th>VALOR ANTES IVA</th>
                <th>IVA </th>
                <th>VALOR FACTURA</th>
              </tr>
            </thead>
            <tbody>{generarTabla()}</tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default VentasPorCliente;
