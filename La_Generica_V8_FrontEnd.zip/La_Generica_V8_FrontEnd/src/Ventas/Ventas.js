import "./ventas.css";
import Menu from "../Menu/Menu";
import React, { useMemo,useState,Component,useEffect} from "react";
import Select from 'react-select';
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import { createSearchParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";


var textico = "nada"; 
/*
var ced_Usu = "";
var nomb_Usu = ""; 
*/
var opc_Usu = [{value: 0 , label: "Seleccione Usuario" }];
var opc_Cli = [{value: 0 , label: "Seleccione Cliente" }];
var opc_Pro = [{value: 0 , label: "Seleccione Producto", precioV: 0}];
var opc_Ciudad = [{value: "Bogota" , label: "Bogota" },{value: "Cali" , label: "Cali" },{value: "Medellin" , label: "Medellin" }];

var codFacturas = 0;

var precioProducto1 = 0;
var precioProducto2 = 0;
var precioProducto3 = 0;

var cantProducto1 = 0;
var cantProducto2 = 0;
var cantProducto3 = 0;


function Ventas() 
{
  const [infoUsuarios, modificarInfoUsuarios] = useState([]); //useState sirve para renderizar al notar un cambio
  //var usuariosLista = null; 
  const [infoClientes, modificarInfoClientes] = useState([]);
  const MySwal = withReactContent(Swal);
  const navigate = useNavigate();

  const cargarUsuarios = async () => {
    const response = await fetch("http://localhost:8080/listarUsuario");
    //const response = await fetch("http://localhost:8080/Usuario/"+123);
    const data = await response.json();
    modificarInfoUsuarios(data);
    //document.getElementById("inputUsuario").value = infoUsuarios.cedula_Usuario;
    //document.getElementById("inputUsuario").value = JSON.stringify(infoUsuarios);
 
    //let ced_Usu = "";
    //let nomb_Usu = ""; 

    /* okokokokoko
    for(const x in data){
      nomb_Usu += data[parseInt(x)].usuario+ " ";
      ced_Usu += data[parseInt(x)].cedula_Usuario+ " ";
    }
    */
/*
    opc_Usu[0] = {value: + 10 , label: "CeratiLabel" };
    opc_Usu[1] = {value: + 20 , label: "CharlyLabel" };
*/

    for(const x in data){
     // nomb_Usu += data[parseInt(x)].usuario+ " ";
     // ced_Usu += data[parseInt(x)].cedula_Usuario+ " ";
      opc_Usu.push({value: parseInt(data[parseInt(x)].cedula_Usuario) , label: data[parseInt(x)].usuario });

    }

    // opc_Usu.push({value: 10 , label: "CeratiLabel" });
    

    //opc_Usu = [].concat(opc_Usu,arr);
    //opc_Usu = [...opc_Usu,...arr]; 
    /*
    const opciones = [
      {    value: "Usu1", label:"Usuario1" },
      {    value: "Usu2", label:"Usuario2" },
      {    value: "Usu3", label:"Usuario3" },
    ]
    */
    //opcionesok = JSON.parse("["+"value:"+ced_Usu+", label:"+ced_Usu+"]");
    //opcok2 = JSON.parse("["+opcionesok+"]");

   /* 
    let text = "";
    let i = 0; 
    for(const x in data){
      text += data[parseInt(x)].usuario+ " ";
      i++;
    }
   */ 
    //let text = data[1].usuario; // cerati
    //document.getElementById("inputUsuario").value = ced_Usu;
    //document.getElementById("inputCliente").value = nomb_Usu;  
    //document.getElementById("inputUsuario").value = JSON.stringify(infoUsuarios);
  };  

  const cargarClientes = async () => {
    const response = await fetch("http://localhost:8080/listarCliente");
    const data = await response.json();
    modificarInfoClientes(data);
    for(const x in data){
      opc_Cli.push({value: parseInt(data[parseInt(x)].cedula_Cliente) , label: data[parseInt(x)].nombre_Cliente });
    }
  };

  const cargarFactura = async () => {
    const response = await fetch("http://localhost:8080/listarFacturas");
    const data = await response.json();
    modificarInfoClientes(data);
    for(const x in data){
      if(codFacturas < parseInt(data[parseInt(x)].codigo_Vta)) {
        codFacturas = parseInt(data[parseInt(x)].codigo_Vta);
        //codFacturas.push([parseInt(data[parseInt(x)].codigo_Vta)]);
      }
    }
    document.getElementById("codigo_Vta").value = codFacturas+1 ;
    //document.getElementById("codigo_Vta").value = "f" ;
  };

  const cargarProductos = async () => {
    const response = await fetch("http://localhost:8080/listarProducto");
    const data = await response.json();
    modificarInfoClientes(data);
    for(const x in data){
      opc_Pro.push({value: data[parseInt(x)].codigo_Producto , 
                    label: data[parseInt(x)].nombre_Producto, 
                    precioV: data[parseInt(x)].precio_Venta_Producto });
    }
  };

/*
  const opciones = [
    {    value: "Usu1", label:"Usuario1" },
    {    value: "Usu2", label:"Usuario2" },
    {    value: "Usu3", label:"Usuario3" },
  ]
  const opcionesCliente = [
    {    value: "Cli1", label:"Cliente1" },
    {    value: "Cli2", label:"Cliente2" },
    {    value: "Cli3", label:"Cliente3" },
  ]
  */
    //const cargarUsuarios = async () => {
    const mostarUsuarios = async (e) => {    
    document.getElementById("selectUsuario").value = e.value; 
    //document.getElementById("inputUsuario").value = "FF";  
  }

    const mostarClientes = async  (e) => {
    document.getElementById("selectCliente").value = e.value;
  }

    const modificarCiudad = async (e) =>{
      document.getElementById("selectCiudad").value = e.value; 
    }
    const mostarProductos = async  (e) => {
      document.getElementById("inputProducto1").value = e.value;
      document.getElementById("precio_SinIVA1").value = e.precioV;
    }
    const mostarProductos2 = async  (e) => {
      document.getElementById("inputProducto2").value = e.value;
      document.getElementById("precio_SinIVA2").value = e.precioV;
    }
    const mostarProductos3 = async  (e) => {
      document.getElementById("inputProducto3").value = e.value;
      document.getElementById("precio_SinIVA3").value = e.precioV;
    }

    const calcularFactura = async  () => {
     
      try{
         precioProducto1 = parseFloat(document.getElementById("precio_SinIVA1").value);
         precioProducto2 = parseFloat(document.getElementById("precio_SinIVA2").value);
         precioProducto3 = parseFloat(document.getElementById("precio_SinIVA3").value);

         cantProducto1 = parseInt(document.getElementById("cantidadProducto1").value);
         cantProducto2 = parseInt(document.getElementById("cantidadProducto2").value);
         cantProducto3 = parseInt(document.getElementById("cantidadProducto3").value);
      }
      catch(err){
        console.error(err);
      }

      //if(totalProducto1 != null && totalProducto2 != null && totalProducto3 != null){
      if(precioProducto1 != null && precioProducto2 != null && precioProducto3 != null &&
        cantProducto1 != null && cantProducto2 != null && cantProducto3 != null
        ){
          var totalProducto1 = precioProducto1*cantProducto1
          var totalProducto2 = precioProducto2*cantProducto2
          var totalProducto3 = precioProducto3*cantProducto3
        
          if(totalProducto1 !== null && totalProducto2 !== null && totalProducto3 !== null){  
 
            document.getElementById("valor_sinIVA1").value = totalProducto1 ;
            document.getElementById("valor_sinIVA2").value = totalProducto2 ;
            document.getElementById("valor_sinIVA3").value = totalProducto3 ;

            var totaNoIva = totalProducto1+totalProducto2+totalProducto3;
            document.getElementById("inputSubTotalSinIVA").value = totaNoIva ;

            var valorIva = totalProducto1*0.19+totalProducto2*0.19+totalProducto3*0.19;
            document.getElementById("inputValorIVA").value = valorIva ;
            document.getElementById("datoValorIVA").value = valorIva ;

            var valorTotal= totaNoIva+valorIva;
            document.getElementById("inputValorTotalFactura").value = valorTotal ;
            document.getElementById("datoValorFactura").value = valorTotal ;

            crearNuevaFactura();
           
          }

        }
    }

    const eliminarProducto1 = async () => {
      document.getElementById("selectProducto1").value = null;
      document.getElementById("inputProducto1").value = null;
      document.getElementById("precio_SinIVA1").value = null;
      document.getElementById("cantidadProducto1").value = null;
      document.getElementById("valor_sinIVA1").value = null;
    }

    const eliminarProducto2 = async () => {
      document.getElementById("selectProducto2").value = null;
      document.getElementById("inputProducto2").value = null;
      document.getElementById("precio_SinIVA2").value = null;
      document.getElementById("cantidadProducto2").value = null;
      document.getElementById("valor_sinIVA2").value = null;
    }

    const eliminarProducto3 = async () => {
      document.getElementById("selectProducto3").value = null;
      document.getElementById("inputProducto3").value = null;
      document.getElementById("precio_SinIVA3").value = null;
      document.getElementById("cantidadProducto3").value = null;
      document.getElementById("valor_sinIVA3").value = null;
    }

    const buscarNombre= async (cedula) => {
 
      //const response = await fetch("http://localhost:8080/Cliente/"+parseInt(cedula));
      const response = await fetch("http://localhost:8080/Cliente/"+1014);
      const data = await response.json();
      modificarInfoUsuarios(data);
      //return data.nombre_Cliente;
      return <h>juanito</h>
      //textico = "Juanito";
      /*
      for(const x in data){
        // nomb_Usu += data[parseInt(x)].usuario+ " ";
        // ced_Usu += data[parseInt(x)].cedula_Usuario+ " ";
        if(parseInt(cedula) == parseInt(data[parseInt(x)].cedula_Usuario) )
        {
          return data[parseInt(x)].usuario;
        }
   
       }*/

    }
    const crearNuevaFactura = async () => {
      //e.preventDefault(); 

      const codigoVta = document.getElementById("codigo_Vta").value;
      const cedulaUsuVta = document.getElementById("selectUsuario").value;
      const cedulaCliVta = document.getElementById("selectCliente").value;
      
      const response = await fetch("http://localhost:8080/Cliente/"+cedulaCliVta);
      const data = await response.json();
      modificarInfoUsuarios(data);
    
      const nombreCliVta = data.nombre_Cliente; 
      const valorVta = document.getElementById("inputSubTotalSinIVA").value;
      const valorIVA = document.getElementById("datoValorIVA").value;
      const valorTotal = document.getElementById("datoValorFactura").value;
      const ciudadValor = document.getElementById("selectCiudad").value;
      //const ciudadValor = "Pasto";

      if (
        codigoVta &&
        cedulaUsuVta &&
        cedulaCliVta &&
        nombreCliVta &&
        valorVta &&
        valorIVA &&
        valorTotal&&
        ciudadValor

      ) {
        const facturaCompleta = {
          codigo_Vta : codigoVta,
          cedula_Usu_Vta : cedulaUsuVta,
          cedula_Cli_Vta : cedulaCliVta,
          nombre_Cli_Vta : nombreCliVta,
          valor_Vta :valorVta,
          valor_IVA :valorIVA,
          valor_Total: valorTotal,
          ciudad:ciudadValor,
          // usuario, clave_Usuario son las variables del modelo en eclipse mismo nombre
        };
        const response = await fetch("http://localhost:8080/saveFactura", {
          //aqui envia la inf
          method: "POST", // *GET, POST, PUT, DELETE, etc.
          mode: "cors", // no-cors, *cors, same-origin
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(facturaCompleta), // body data type must match "Content-Type" header
        });
        const respuesta = await response.json();
  
        if (respuesta) {
          MySwal.fire(
            "Factura Guardada",
            "La factura se agrego exitosamente",
            "success"
          );
  
          navigate("/Ventas");
          document.getElementById("codigo_Vta").value = parseInt(codigoVta)+1 ;
          
        } else {
          MySwal.fire(
            "Datos Incompletos",
            "Por favor complete todos los campos",
            "error"
          );
        }
      }
    };
  

    useEffect(() => {
      //sirve para ejecutar esa funcion apenas carga o cuando cambia una variable dentro de la funcion
      cargarUsuarios();
      cargarClientes();
      cargarProductos();
      cargarFactura();
       
      document.getElementById("FechaActual").value = new Date(); 
    }, []);

  return (
    <div className="flex">
      <Menu></Menu>
      <div className="anchoMenu">
        <form method="POST">
          <div class="VentasTitulo">
            <h1>Factura Tienda La Generica</h1>
          </div>
          <div className="Contenido_Ventas_Informacion">
            <table className="tabla_Datos">
              <tr>
                <td>
                  <label>Usuario </label>
                </td>
                <td>
                  <Select
                    id = "selectUsuario" 
                    onChange={(e) => mostarUsuarios(e) }
                    options ={opc_Usu}//{opciones} 
                  />
                </td>
              </tr>
              <tr>
                <td>
                  <label>Cliente </label>
                </td>
                <td>
                <Select
                    id = "selectCliente" 
                    onChange={(e) => mostarClientes(e) }
                    options ={opc_Cli} 
                  />
                  <input
                    id="nombre_Cli_Vta"
                    name="nombre_Cli_Vta"
                    type="hidden"
                    value=""
                  />
                </td>


              </tr>
              <tr>
                <td>
                  <label>Fecha y Hora </label>
                </td>
                <td>
                  <input
                    id="FechaActual"
                    type="text"
                    name="datos_Fecha"
                    className=" border_input tabla_td_select"
                  />
                </td>
              </tr>
              <td>
                  <label>Ciudad </label>
                </td>
              <td>
                  <Select
                    id = "selectCiudad" 
                    onChange={(e) => modificarCiudad(e) }
                    options ={opc_Ciudad} 
                  />          

                  <input
                    id="HoraActual"
                    type="text"
                    name="datos_Hora"
                    className=" border_input tabla_td_select"
                  />
                </td>
                
            </table>

            <table className="tabla_CodigoTotales">
              <tr>
                <td>
                  <label>Factura </label>
                </td>
                <td>
                  <input
                    id="codigo_Vta"
                    type="text"
                    name="codigo_Vta"
                    className=" border_input tabla_td_select alignCenter"
                  />
                </td>
              </tr>

              <tr>
                <td>
                  <label>Valor Factura </label>
                </td>
                <td>
                  <input
                    id="datoValorFactura"
                    type="text"
                    name="datoValorFactura"
                    className=" border_input tabla_td_select alignCenter "
                  />
                </td>
              </tr>

              <tr>
                <td>
                  <label>Valor IVA </label>
                </td>
                <td>
                  <input
                    id="datoValorIVA" 
                    type="text"
                    name=""
                    className=" border_input tabla_td_select alignCenter"
                  />
                </td>
              </tr>
            </table>
          </div>

          <div className="Contenido_Ventas_Factura">
            <table className="tabla_Factura ">
              <tr>
                <th className="bordes_Tabla color_Gris">Cod. Producto</th>
                <th className="bordes_Tabla color_Gris">Nombre Producto</th>
                <th className="bordes_Tabla color_Gris">Precio Venta</th>
                <th className="bordes_Tabla color_Gris">Cantidad</th>
                <th className="bordes_Tabla color_Gris">Vlr. Total</th>
                <th>
                <td className="alignCenter">
                  <button
                    type="button" 
                    onClick={() => calcularFactura()}/*"eliminarFilaProducto1()"*/
                    className="btn btn-success btn-sm bi bi-calculator"
                  >
                    Facturar
                  </button>
                </td>
                </th>
              </tr>
              



              <tr>
                <td className="bordes_Tabla">
                  <input
                    id="inputProducto1"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                  />
                </td>

                <td className="bordes_Tabla">

                  <Select
                      id = "selectProducto1" 
                      onChange={(e) => mostarProductos(e) }
                      options ={opc_Pro}//{opciones} 
                    />

                </td>

                <td className="bordes_Tabla">
                  <input
                    id="precio_SinIVA1"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="precio_SinIVA"
                    disabled="disabled"
                  />
                </td>

                <td className="bordes_Tabla">
                  <input
                    id="cantidadProducto1"
                    onchange="hallarValorTotalSinIVA1()"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="cantidad"
                  />
                </td>

                <td className="bordes_Tabla">
                  <input
                    id="valor_sinIVA1"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="valor_sinIVA1"
                  />
                </td>

                <td className="alignCenter">
                  <button
                    type="button" 
                    onClick={() => eliminarProducto1()}
                    className="btn btn-danger btn-sm bi bi-trash "
                  >
                    
                  </button>
                </td>
              </tr>

              <tr>
                <td className="bordes_Tabla">
                  <input
                    id="inputProducto2"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                  />
                </td>

                <td className="bordes_Tabla">
                <Select
                      id = "selectProducto2" 
                      onChange={(e) => mostarProductos2(e) }
                      options ={opc_Pro}//{opciones} 
                    />
                </td>

                <td className="bordes_Tabla">
                  <input
                    id="precio_SinIVA2"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="precio_SinIVA"
                    disabled="disabled"
                  />
                </td>

                <td className="bordes_Tabla">
                  <input
                    id="cantidadProducto2"
                    onchange="hallarValorTotalSinIVA2()"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="cantidad"
                  />
                </td>

                <td className="bordes_Tabla">
                  <input
                    id="valor_sinIVA2"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="valor_sinIVA2"
                  />
                </td>

                <td className="alignCenter">
                  <button
                    type="button"
                    onClick={() => eliminarProducto2()}
                    className="btn btn-danger btn-sm bi bi-trash "
                  >
                    
                  </button>
                </td>
              </tr>

              <tr>
                <td className="bordes_Tabla">
                  <input
                    id="inputProducto3"
                    type="text"
                    name="cod_Producto"
                    className=" border_input"
                    disabled="disabled"
                  />
                </td>

                <td className="bordes_Tabla">
                <Select
                      id = "selectProducto3" 
                      onChange={(e) => mostarProductos3(e) }
                      options ={opc_Pro}//{opciones} 
                    />
                </td>

                <td className="bordes_Tabla">
                  <input
                    id="precio_SinIVA3"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="precio_SinIVA"
                    disabled="disabled"
                  />
                </td>

                <td className="bordes_Tabla">
                  <input
                    id="cantidadProducto3"
                    onchange="hallarValorTotalSinIVA3()"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="cantidad"
                  />
                </td>

                <td className="bordes_Tabla">
                  <input
                    id="valor_sinIVA3"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="valor_sinIVA3"
                  />
                </td>

                <td className="alignCenter">
                  <button
                    id="eliminarProducto3"
                    type="button"
                    onClick={() => eliminarProducto3()}
                    className="btn btn-danger btn-sm bi bi-trash "
                  >
                  </button>
                </td>
              </tr>

              <tr>
                <td rowspan="3 " colspan="3"></td>

                <td className="bordes_Tabla">
                  <label className="padding-left" for="sub_Total_Factura">
                    {" "}
                    Sub. Total Factura{" "}
                  </label>
                </td>

                <td className="bordes_Tabla">
                  <input
                    id="inputSubTotalSinIVA"
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="valor_Vta"
                  />
                </td>
                <td></td>
              </tr>
              <tr>
                <td className="bordes_Tabla">
                  <label className="padding-left" for="valor_IVA">
                    {" "}
                    Valor IVA{" "}
                  </label>
                </td>
                <td className="bordes_Tabla">
                  <input
                    id="inputValorIVA" 
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="valor_IVA"
                  />
                </td>
                <td></td>
              </tr>
              <tr>
                <td className="bordes_Tabla">
                  <label className="padding-left" for="total_Factura">
                    {" "}
                    Total Factura{" "}
                  </label>
                </td>
                <td className="bordes_Tabla">
                  <input
                    id="inputValorTotalFactura" 
                    className=" border_input tabla_td_select select_Producto"
                    type="text"
                    name="valor_Total"
                  />
                </td>
                





              </tr>
            </table>
          </div>
        </form>
      </div>
    </div>
  );
}
// document.getElementById("HoraActual").value = textico;
// console.log("Hola FF"); 
export default Ventas;


/*

                  <select
                    id="selectUsuario"
                    onchange="completarUsuario()"
                    className="tabla_td_select"
                  >
                    <option value="0">Seleccione el usuario:</option>
                    <option value="1">Usuario1</option>
                  </select>


                */

/*
                  <td className="alignCenter">
                  <button 
                    //id="btn_facturar"
                    type="submit" 
                    name="btnFacturar"
                    className="btn btn-danger btn-sm bi bi-trash "
                    //onClick={calcularFactura(1)}
                    >
                    {" "}
                    Facturar{" "}
                  </button>
                </td>

                */

                /*
                 <select>
                    <option value="Bogota">Bogota</option> 
                    <option value="Cali">Cali</option>
                  </select>
                  */